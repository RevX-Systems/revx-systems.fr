'use strict';

// FormSubmit migration of the V5 contact form.
// The form.action is the EXISTING active /ajax/ endpoint from REVX V2.
// No PHP backend is required on GitHub Pages.
(function () {
  const form = document.getElementById('revx-contact-form');
  if (!form) return;

  const subject = document.getElementById('objet');
  const notice = document.getElementById('form-feedback');
  const submit = form.querySelector('button[type="submit"]');
  const acceptedSubjects = new Set(['prestation', 'solution', 'autre']);
  const querySubject = new URLSearchParams(window.location.search).get('objet');

  // Preserve V5 deep links from the landing page.
  if (subject && acceptedSubjects.has(querySubject)) {
    subject.value = querySubject;
  }

  function feedback(message) {
    if (!notice) return;
    notice.textContent = message;
    notice.hidden = false;
    notice.classList.add('is-error');
    notice.focus();
  }

  const isLocalPreview =
    location.protocol === 'file:' ||
    ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity() || submit?.disabled) return;

    if (isLocalPreview) {
      feedback('Aperçu local : aucun e-mail envoyé. Le formulaire doit être testé une seule fois sur le site publié.');
      return;
    }

    // FormSubmit uses _honey for spam detection, not the legacy PHP site_internet.
    if (form.elements.namedItem('_honey')?.value) {
      feedback('Votre demande n’a pas pu être envoyée.');
      return;
    }

    if (submit) submit.disabled = true;
    if (notice) notice.hidden = true;

    try {
      const response = await fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { Accept: 'application/json' },
      });

      // Expect a JSON response from the FormSubmit /ajax/ endpoint.
      // Do not mistake an HTTP error page for a successful message.
      const contentType = response.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error('Réponse FormSubmit non JSON');
      }
      const result = await response.json();
      const explicitlyFailed =
        result?.success === false ||
        result?.success === 'false' ||
        result?.ok === false ||
        Boolean(result?.error);

      if (!response.ok || explicitlyFailed) {
        throw new Error('Envoi refusé par FormSubmit');
      }

      // Keep the original REVX V2 journey: successful AJAX POST → thank-you page.
      window.location.assign('merci.html');
    } catch (error) {
      feedback('Votre demande n’a pas pu être transmise. Réessayez ou écrivez à contact@revx-systems.fr.');
      if (submit) submit.disabled = false;
    }
  });
})();
